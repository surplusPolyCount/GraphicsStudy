using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class GameManager : MonoBehaviour
{
    public bool canEditTerrain = true;
    public GameObject terrain; 
    public GameObject ball;

    private void Start()
    {
        ball = GameObject.Find("player");
        terrain = GameObject.Find("terrainCtrl"); 
    }
    public void Play()
    {
        terrain.GetComponent<CursorTerrainEditor>().CanEdit = false;
        ball.GetComponent<Rigidbody2D>().bodyType = RigidbodyType2D.Dynamic;
    }
}
